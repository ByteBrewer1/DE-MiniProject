# radix
Convert between bases with this simple radix conversion tool.

## Demo
* [GitHub Pages](https://charlesstover.github.io/radix/)
